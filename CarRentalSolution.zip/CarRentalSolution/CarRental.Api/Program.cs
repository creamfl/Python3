using Microsoft.EntityFrameworkCore;
using CarRental.Data;
using CarRental.Data.Interfaces;
using CarRental.Data.Repositories;
using CarRental.Service.Interfaces;
using CarRental.Service.Services;
using CarRental.Service.Profiles; // Ensure this using directive is present

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // 1. Add DbContext
        builder.Services.AddDbContext<CarRentalContext>(options =>
            options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"),
                // Specify migrations assembly if it's in the .Data project
                sqlServerOptionsAction: sqlOptions =>
                {
                    sqlOptions.MigrationsAssembly(typeof(CarRentalContext).Assembly.FullName);
                }
            ));

        // 2. Add Repositories
        builder.Services.AddScoped<IClientRepository, ClientRepository>();
        builder.Services.AddScoped<ICarRepository, CarRepository>();

        // 3. Add Services
        builder.Services.AddScoped<IClientService, ClientService>();
        builder.Services.AddScoped<ICarService, CarService>();

        // 4. Add AutoMapper
        // It will scan the assembly containing ClientProfile (and CarProfile) for all profiles
        builder.Services.AddAutoMapper(typeof(ClientProfile), typeof(CarProfile));

        // Add services to the container.
        builder.Services.AddControllers();
        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();
        app.UseAuthorization();
        app.MapControllers();
        app.Run();
    }
}