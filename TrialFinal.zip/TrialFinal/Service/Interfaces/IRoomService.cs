﻿using Service.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Service.Interfaces
{
    public interface IRoomService
    {
        Task<IEnumerable<RoomReadOnlyDto>> GetAllRoomsAsync();
        Task<RoomReadOnlyDto?> GetRoomByIdAsync(int id);
        Task<RoomReadOnlyDto?> CreateRoomAsync(RoomCreateUpdateDto roomDto);
        Task<bool> UpdateRoomAsync(int id, RoomCreateUpdateDto roomDto);
        Task<bool> DeleteRoomAsync(int id);
    }
}