﻿using Service.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Service.Interfaces
{
    public interface IGuestService
    {
        Task<IEnumerable<GuestReadOnlyDto>> GetAllGuestsAsync();
        Task<GuestReadOnlyDto?> GetGuestByIdAsync(int id);
        Task<GuestReadOnlyDto?> CreateGuestAsync(GuestCreateUpdateDto guestDto);
        Task<bool> UpdateGuestAsync(int id, GuestCreateUpdateDto guestDto);
        Task<bool> DeleteGuestAsync(int id);
    }
}