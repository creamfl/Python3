﻿using Data.Entities;
using Data.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Data.Repositories
{
    public class GuestRepository : IGuestRepository
    {
        private readonly AppDbContext _context;

        public GuestRepository(AppDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<IEnumerable<Guest>> GetAllAsync()
        {
            return await _context.Guests
                .Include(g => g.Room)
                .ToListAsync();
        }

        public async Task<Guest?> GetByIdAsync(int id)
        {
            return await _context.Guests
                .Include(g => g.Room)
                .FirstOrDefaultAsync(g => g.Id == id);
        }

        public async Task AddAsync(Guest entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));

            await _context.Guests.AddAsync(entity);
        }

        public void Update(Guest entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));

            _context.Guests.Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;
        }

        public void Delete(Guest entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));

            if (_context.Entry(entity).State == EntityState.Detached)
            {
                _context.Guests.Attach(entity);
            }
            _context.Guests.Remove(entity);
        }

        public async Task DeleteAsync(int id)
        {
            var guest = await GetByIdAsync(id); 
            if (guest != null)
            {
                Delete(guest); 
            }
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }


        public async Task<IEnumerable<Guest>> GetGuestsByRoomIdAsync(int roomId)
        {
            return await _context.Guests
                .Where(g => g.RoomId == roomId)
                .Include(g => g.Room) 
                .ToListAsync();
        }

        public async Task<IEnumerable<Guest>> GetCurrentGuestsAsync()
        {
            var today = DateTime.Today; 
            return await _context.Guests
                .Where(g => g.CheckInDate <= today && g.CheckOutDate >= today)
                .Include(g => g.Room)
                .ToListAsync();
        }

        public async Task<bool> RoomHasGuestsAsync(int roomId)
        {
            return await _context.Guests.AnyAsync(g => g.RoomId == roomId);
        }
    }
}