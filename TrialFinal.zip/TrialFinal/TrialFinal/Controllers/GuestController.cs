﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service.DTOs;
using Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TrialFinal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GuestsController : ControllerBase
    {
        private readonly IGuestService _guestService;
        private readonly ILogger<GuestsController> _logger;

        public GuestsController(IGuestService guestService, ILogger<GuestsController> logger)
        {
            _guestService = guestService ?? throw new ArgumentNullException(nameof(guestService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<GuestReadOnlyDto>), StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<GuestReadOnlyDto>>> GetAllGuests()
        {
            _logger.LogInformation("Attempting to get all guests.");
            var guests = await _guestService.GetAllGuestsAsync();
            return Ok(guests);
        }

        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(GuestReadOnlyDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<GuestReadOnlyDto>> GetGuestById(int id)
        {
            _logger.LogInformation("Attempting to get guest with ID: {GuestId}", id);
            var guest = await _guestService.GetGuestByIdAsync(id);
            if (guest == null)
            {
                _logger.LogWarning("Guest with ID: {GuestId} not found.", id);
                return NotFound($"Guest with ID {id} not found.");
            }
            return Ok(guest);
        }

        [HttpPost]
        [ProducesResponseType(typeof(GuestReadOnlyDto), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<GuestReadOnlyDto>> CreateGuest([FromBody] GuestCreateUpdateDto guestDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                _logger.LogInformation("Attempting to create a new guest: {GuestFirstName} {GuestLastName}", guestDto.FirstName, guestDto.LastName);
                var createdGuest = await _guestService.CreateGuestAsync(guestDto);
                if (createdGuest == null)
                {
                    _logger.LogWarning("Guest creation failed due to service-level validation for guest: {GuestFirstName} {GuestLastName}", guestDto.FirstName, guestDto.LastName);
                    return BadRequest("Guest creation failed. Please check input data (e.g., room ID, dates).");
                }
                return CreatedAtAction(nameof(GetGuestById), new { id = createdGuest.Id }, createdGuest);
            }
            catch (ArgumentException ex)
            {
                _logger.LogWarning(ex, "Argument error while creating guest: {GuestFirstName} {GuestLastName}", guestDto.FirstName, guestDto.LastName);
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error while creating guest: {GuestFirstName} {GuestLastName}", guestDto.FirstName, guestDto.LastName);
                return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred while creating the guest.");
            }
        }

        [HttpPut("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateGuest(int id, [FromBody] GuestCreateUpdateDto guestDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("Attempting to update guest with ID: {GuestId}", id);
            var success = await _guestService.UpdateGuestAsync(id, guestDto);

            if (!success)
            {
                var guestExists = await _guestService.GetGuestByIdAsync(id);
                if (guestExists == null)
                {
                    _logger.LogWarning("Attempted to update non-existent guest with ID: {GuestId}", id);
                    return NotFound($"Guest with ID {id} not found.");
                }
                _logger.LogWarning("Update failed for guest ID: {GuestId}. Possible invalid input (e.g., room ID, dates).", id);
                return BadRequest("Guest update failed. Please check input data.");
            }
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteGuest(int id)
        {
            _logger.LogInformation("Attempting to delete guest with ID: {GuestId}", id);
            var success = await _guestService.DeleteGuestAsync(id);
            if (!success)
            {
                _logger.LogWarning("Attempted to delete non-existent guest or delete failed for ID: {GuestId}", id);
                return NotFound($"Guest with ID {id} not found or could not be deleted.");
            }
            return NoContent();
        }
    }
}
