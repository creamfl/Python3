﻿namespace CarRental.Service;

public class Class1
{

}
