﻿using Data.Entities;
using Microsoft.EntityFrameworkCore;
using System;

namespace Data
{
    public class AppDbContext : DbContext
    {
        public virtual DbSet<Guest> Guests { get; set; } = null!;
        public virtual DbSet<Room> Rooms { get; set; } = null!;

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Guest>(entity =>
            {
                entity.ToTable("Guests");

                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.FirstName).IsRequired().HasMaxLength(200);
                entity.Property(e => e.LastName).IsRequired().HasMaxLength(400);
                entity.Property(e => e.DOB).IsRequired();
                entity.Property(e => e.Address).IsRequired().HasMaxLength(600);
                entity.Property(e => e.Nationality).IsRequired();
                entity.Property(e => e.CheckInDate).IsRequired();
                entity.Property(e => e.CheckOutDate).IsRequired();
                entity.Property(e => e.RoomId).IsRequired();

                entity.HasOne(g => g.Room)
                      .WithMany(r => r.Guests)
                      .HasForeignKey(g => g.RoomId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<Room>(entity =>
            {
                entity.ToTable("Rooms");

                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Number).IsRequired();
                entity.Property(e => e.Floor).IsRequired();
                entity.Property(e => e.Type).IsRequired();
            });
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite("Data Source=HotelManagement_Fallback.db");
            }
        }
    }
}
