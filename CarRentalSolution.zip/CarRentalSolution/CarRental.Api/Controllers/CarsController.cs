using Microsoft.AspNetCore.Mvc;
using CarRental.Service.Interfaces;
using CarRental.Service.DTOs;
using System.Collections.Generic;

namespace CarRental.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        private readonly ICarService _carService;

        public CarsController(ICarService carService)
        {
            _carService = carService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<CarDTO>> GetAllCars()
        {
            var cars = _carService.GetAllCars();
            return Ok(cars);
        }

        [HttpGet("{id}")]
        public ActionResult<CarDTO> GetCarById(int id)
        {
            var car = _carService.GetCarById(id);
            if (car == null)
            {
                return NotFound();
            }
            return Ok(car);
        }

        [HttpPost]
        public ActionResult<CarDTO> CreateCar([FromBody] CreateCarDTO createCarDto)
        {
             if (!ModelState.IsValid) return BadRequest(ModelState);
            try
            {
                var createdCar = _carService.CreateCar(createCarDto);
                return CreatedAtAction(nameof(GetCarById), new { id = createdCar.Id }, createdCar);
            }
            catch (Exception ex)
            {
                // Log the exception ex here
                return StatusCode(500, "An unexpected error occurred.");
            }
        }

        [HttpPut("{id}")]
        public IActionResult UpdateCar(int id, [FromBody] UpdateCarDTO updateCarDto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            try
            {
                _carService.UpdateCar(id, updateCarDto);
                return NoContent();
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                // Log the exception ex here
                return StatusCode(500, "An unexpected error occurred.");
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCar(int id)
        {
             try
            {
                _carService.DeleteCar(id);
                return NoContent();
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                // Log the exception ex here
                return StatusCode(500, "An unexpected error occurred.");
            }
        }
    }
}