using AutoMapper;
using CarRental.Data.Entities;
using CarRental.Data.Interfaces;
using CarRental.Service.DTOs;
using CarRental.Service.Interfaces;
using System.Collections.Generic;

namespace CarRental.Service.Services
{
    public class ClientService : IClientService
    {
        private readonly IClientRepository _clientRepository;
        private readonly ICarRepository _carRepository;
        private readonly IMapper _mapper;

        public ClientService(IClientRepository clientRepository, ICarRepository carRepository, IMapper mapper)
        {
            _clientRepository = clientRepository;
            _carRepository = carRepository;
            _mapper = mapper;
        }

        public IEnumerable<ClientDTO> GetAllClients()
        {
            var clients = _clientRepository.GetAll();
            return _mapper.Map<IEnumerable<ClientDTO>>(clients);
        }

        public ClientDTO GetClientById(int id)
        {
            var client = _clientRepository.GetById(id);
            return _mapper.Map<ClientDTO>(client);
        }

        public ClientDTO CreateClient(CreateClientDTO clientDto)
        {
            var carExists = _carRepository.GetById(clientDto.CarId);
            if (carExists == null)
            {
                 throw new KeyNotFoundException($"Car with ID {clientDto.CarId} not found.");
            }
            var client = _mapper.Map<Client>(clientDto);
            var createdClient = _clientRepository.Create(client);
            return _mapper.Map<ClientDTO>(createdClient);
        }

        public void UpdateClient(int id, UpdateClientDTO clientDto)
        {
            var existingClient = _clientRepository.GetById(id);
            if (existingClient == null)
            {
                throw new KeyNotFoundException($"Client with ID {id} not found.");
            }
            var carExists = _carRepository.GetById(clientDto.CarId);
            if (carExists == null)
            {
                 throw new KeyNotFoundException($"Car with ID {clientDto.CarId} not found.");
            }
            _mapper.Map(clientDto, existingClient);
            _clientRepository.Update(existingClient);
        }

        public void DeleteClient(int id)
        {
            var existingClient = _clientRepository.GetById(id);
            if (existingClient == null)
            {
                 throw new KeyNotFoundException($"Client with ID {id} not found.");
            }
            _clientRepository.Delete(id);
        }
    }
}