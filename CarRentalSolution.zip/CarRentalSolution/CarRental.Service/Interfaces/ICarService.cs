using CarRental.Service.DTOs;
using System.Collections.Generic;

namespace CarRental.Service.Interfaces
{
    public interface ICarService
    {
        IEnumerable<CarDTO> GetAllCars();
        CarDTO GetCarById(int id);
        CarDTO CreateCar(CreateCarDTO carDto);
        void UpdateCar(int id, UpdateCarDTO carDto);
        void DeleteCar(int id);
    }
}