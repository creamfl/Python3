using CarRental.Data.Entities;
using CarRental.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace CarRental.Data.Repositories
{
    public class ClientRepository : IClientRepository
    {
        private readonly CarRentalContext _context;

        public ClientRepository(CarRentalContext context)
        {
            _context = context;
        }

        public IEnumerable<Client> GetAll()
        {
            return _context.Clients.Include(c => c.Car).ToList();
        }

        public Client GetById(int id)
        {
            return _context.Clients.Include(c => c.Car).FirstOrDefault(c => c.Id == id);
        }

        public Client Create(Client client)
        {
            _context.Clients.Add(client);
            _context.SaveChanges();
            return client;
        }

        public void Update(Client client)
        {
            _context.Clients.Update(client);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var client = _context.Clients.Find(id);
            if (client != null)
            {
                _context.Clients.Remove(client);
                _context.SaveChanges();
            }
        }
    }
}