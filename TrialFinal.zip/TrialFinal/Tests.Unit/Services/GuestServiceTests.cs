using Xunit;
using Moq;
using Service.Services;
using Service.Interfaces;
using Data.Repositories.Interfaces;
using Data.Entities;
using Service.DTOs;
using AutoMapper; 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Hotel.Tests.Unit.Services
{
    public class GuestServiceTests
    {
        private readonly Mock<IGuestRepository> _mockGuestRepository;
        private readonly Mock<IRoomRepository> _mockRoomRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<ILogger<GuestService>> _mockLogger;
        private readonly GuestService _guestService;

        public GuestServiceTests()
        {
            _mockGuestRepository = new Mock<IGuestRepository>();
            _mockRoomRepository = new Mock<IRoomRepository>();
            _mockMapper = new Mock<IMapper>();
            _mockLogger = new Mock<ILogger<GuestService>>();

            _mockMapper.Setup(m => m.Map<GuestReadOnlyDto>(It.IsAny<Guest>()))
                       .Returns((Guest source) => source == null ? null : new GuestReadOnlyDto { Id = source.Id, FirstName = source.FirstName, LastName = source.LastName /* map other props */ });
            _mockMapper.Setup(m => m.Map<Guest>(It.IsAny<GuestCreateUpdateDto>()))
                       .Returns((GuestCreateUpdateDto source) => source == null ? null : new Guest { FirstName = source.FirstName, LastName = source.LastName, RoomId = source.RoomId /* map other props */ });


            _guestService = new GuestService(
                _mockGuestRepository.Object,
                _mockRoomRepository.Object,
                _mockMapper.Object, // Pass the mapper
                _mockLogger.Object
            );
        }

        [Fact]
        public async Task CreateGuestAsync_WhenRoomExistsAndDataIsValid_ShouldReturnCreatedGuestDto()
        {
            // Arrange
            var guestDto = new GuestCreateUpdateDto { FirstName = "John", LastName = "Doe", RoomId = 1, CheckInDate = DateTime.Now, CheckOutDate = DateTime.Now.AddDays(1), Address = "123 Main", DOB = DateTime.Now.AddYears(-30), Nationality = "Test" };
            var guestEntityMappedFromDto = new Guest { FirstName = "John", LastName = "Doe", RoomId = 1, CheckInDate = guestDto.CheckInDate, CheckOutDate = guestDto.CheckOutDate, Address = "123 Main", DOB = guestDto.DOB, Nationality = "Test" };
            var roomEntity = new Room { Id = 1, Number = "101" };
            var guestIdAfterSave = 1; // Expected ID after save

            _mockRoomRepository.Setup(repo => repo.GetByIdAsync(guestDto.RoomId)).ReturnsAsync(roomEntity);
            

            _mockGuestRepository.Setup(repo => repo.AddAsync(It.IsAny<Guest>()))
                .Callback<Guest>(g => {
                    g.Id = guestIdAfterSave; 
                })
                .Returns(Task.CompletedTask); // Ensure it returns a completed task

            _mockGuestRepository.Setup(repo => repo.SaveChangesAsync()).ReturnsAsync(1); // Simulate one record saved

            var guestEntityForGetById = new Guest { Id = guestIdAfterSave, FirstName = guestDto.FirstName, LastName = guestDto.LastName, RoomId = guestDto.RoomId, CheckInDate = guestDto.CheckInDate, CheckOutDate = guestDto.CheckOutDate, Address = guestDto.Address, DOB = guestDto.DOB, Nationality = guestDto.Nationality, Room = roomEntity };
            _mockGuestRepository.Setup(repo => repo.GetByIdAsync(guestIdAfterSave)).ReturnsAsync(guestEntityForGetById);


            _mockMapper.Setup(m => m.Map<Guest>(guestDto)).Returns(guestEntityMappedFromDto);
            _mockMapper.Setup(m => m.Map<GuestReadOnlyDto>(It.Is<Guest>(g => g.Id == guestIdAfterSave)))
                       .Returns(new GuestReadOnlyDto { Id = guestIdAfterSave, FirstName = guestDto.FirstName, LastName = guestDto.LastName, RoomId = guestDto.RoomId });


            // Act
            var result = await _guestService.CreateGuestAsync(guestDto);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(guestDto.FirstName, result.FirstName);
            Assert.Equal(guestIdAfterSave, result.Id); // Check for the specific ID
            _mockGuestRepository.Verify(repo => repo.AddAsync(It.Is<Guest>(g => g.FirstName == guestDto.FirstName)), Times.Once);
            _mockGuestRepository.Verify(repo => repo.SaveChangesAsync(), Times.Once);
        }

        [Fact]
        public async Task CreateGuestAsync_WhenRoomDoesNotExist_ShouldReturnNull()
        {
            // Arrange
            var guestDto = new GuestCreateUpdateDto { RoomId = 99, FirstName = "Test", LastName = "User", CheckInDate = DateTime.Now, CheckOutDate = DateTime.Now.AddDays(1), Address = "123 Main", DOB = DateTime.Now.AddYears(-30), Nationality = "Test" };
            _mockRoomRepository.Setup(repo => repo.GetByIdAsync(guestDto.RoomId)).ReturnsAsync((Room?)null);

            // Act
            var result = await _guestService.CreateGuestAsync(guestDto);

            // Assert
            Assert.Null(result);
            _mockGuestRepository.Verify(repo => repo.AddAsync(It.IsAny<Guest>()), Times.Never);
        }

        [Fact]
        public async Task GetGuestByIdAsync_WhenGuestExists_ShouldReturnGuestDto()
        {
            // Arrange
            var guestId = 1;
            var guestEntity = new Guest { Id = guestId, FirstName = "Jane", LastName = "Doe" };

            _mockGuestRepository.Setup(repo => repo.GetByIdAsync(guestId)).ReturnsAsync(guestEntity);
            _mockMapper.Setup(m => m.Map<GuestReadOnlyDto>(guestEntity))
                       .Returns(new GuestReadOnlyDto { Id = guestEntity.Id, FirstName = guestEntity.FirstName, LastName = guestEntity.LastName });


            // Act
            var result = await _guestService.GetGuestByIdAsync(guestId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(guestId, result.Id);
            Assert.Equal("Jane", result.FirstName);
        }

        [Fact]
        public async Task GetAllGuestsAsync_ShouldReturnAllGuestDtos()
        {
            // Arrange
            var guestEntities = new List<Guest>
            {
                new Guest { Id = 1, FirstName = "John", LastName = "Doe" },
                new Guest { Id = 2, FirstName = "Jane", LastName = "Smith" }
            };
            var guestDtos = new List<GuestReadOnlyDto>
            {
                new GuestReadOnlyDto { Id = 1, FirstName = "John", LastName = "Doe" },
                new GuestReadOnlyDto { Id = 2, FirstName = "Jane", LastName = "Smith" }
            };

            _mockGuestRepository.Setup(repo => repo.GetAllAsync()).ReturnsAsync(guestEntities);
            _mockMapper.Setup(m => m.Map<IEnumerable<GuestReadOnlyDto>>(guestEntities)).Returns(guestDtos);

            // Act
            var result = await _guestService.GetAllGuestsAsync();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count());
        }


        [Fact]
        public async Task DeleteGuestAsync_WhenGuestExists_ShouldReturnTrue()
        {
            // Arrange
            var guestId = 1;
            var guestEntity = new Guest { Id = guestId };
            _mockGuestRepository.Setup(repo => repo.GetByIdAsync(guestId)).ReturnsAsync(guestEntity);
            _mockGuestRepository.Setup(repo => repo.Delete(guestEntity)); 
            _mockGuestRepository.Setup(repo => repo.SaveChangesAsync()).ReturnsAsync(1); 

            // Act
            var result = await _guestService.DeleteGuestAsync(guestId);

            // Assert
            Assert.True(result);
            _mockGuestRepository.Verify(repo => repo.Delete(guestEntity), Times.Once);
            _mockGuestRepository.Verify(repo => repo.SaveChangesAsync(), Times.Once);
        }
    }
}