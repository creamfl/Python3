using Data; // Your DbContext (AppDbContext)
using Data.Repositories; // Your Repository implementations
using Data.Repositories.Interfaces; // Your Repository interfaces
using Microsoft.EntityFrameworkCore; // For UseSqlite, etc.
using Service.Interfaces; // Your Service interfaces (IGuestService, IRoomService)
using Service.Services;   // Your Service implementations (GuestService, RoomService)
using Service.Mappings;   // Your MappingProfile for AutoMapper
using System; // For AppDomain (used by AutoMapper scanning)

var builder = WebApplication.CreateBuilder(args);

// 1. Add services to the container.

// Controllers: This enables your API controllers.
builder.Services.AddControllers();

// Swagger/OpenAPI: For API documentation and testing UI.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(); // You can add more Swagger config here if needed

// Database Context (AppDbContext): Configured to use SQLite.
// The connection string "DefaultConnection" will be read from appsettings.json.
// MigrationsAssembly is set to "Data" because your migrations are in the Data project.
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        b => b.MigrationsAssembly("Data")
    ));

// Repositories: Registering your repository interfaces with their implementations.
// AddScoped means a new instance is created for each HTTP request.
builder.Services.AddScoped<IGuestRepository, GuestRepository>();
builder.Services.AddScoped<IRoomRepository, RoomRepository>();

// Services: Registering your service interfaces with their implementations.
builder.Services.AddScoped<IGuestService, GuestService>();
builder.Services.AddScoped<IRoomService, RoomService>();

// AutoMapper: This finds your MappingProfile and sets up AutoMapper.
// It scans all assemblies in the current application domain.
builder.Services.AddAutoMapper(typeof(MappingProfile).Assembly); // More specific: typeof(MappingProfile).Assembly
// Or, if MappingProfile is in a different assembly that's part of the app:
// builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());


// CORS (Cross-Origin Resource Sharing): Allows your API to be called from different domains (e.g., a frontend app).
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", // Give the policy a name
        policyBuilder => policyBuilder.AllowAnyOrigin() // Allow requests from any origin (domain)
                         .AllowAnyMethod()  // Allow any HTTP method (GET, POST, etc.)
                         .AllowAnyHeader()); // Allow any HTTP headers
});

var app = builder.Build();

// 2. Configure the HTTP request pipeline.
// This defines how incoming requests are handled by middleware.

if (app.Environment.IsDevelopment()) // Only use Swagger in development
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        // Serve Swagger UI at the app's root (e.g., https://localhost:xxxx/)
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Hotel Management API V1");
        c.RoutePrefix = string.Empty;
    });
}

app.UseHttpsRedirection(); // Automatically redirect HTTP requests to HTTPS

app.UseCors("AllowAll"); // Apply the CORS policy we defined

// app.UseAuthentication(); // If you add authentication, uncomment this
app.UseAuthorization(); // Enables authorization features

app.MapControllers(); // This maps requests to your API controller actions

app.Run(); // Start the application and listen for requests
