﻿using Data.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Data.Repositories.Interfaces
{
    public interface IGuestRepository
    {
        Task<IEnumerable<Guest>> GetAllAsync();
        Task<Guest?> GetByIdAsync(int id);
        Task AddAsync(Guest entity);
        void Update(Guest entity);
        void Delete(Guest entity);
        Task DeleteAsync(int id);
        Task<int> SaveChangesAsync();

        Task<IEnumerable<Guest>> GetGuestsByRoomIdAsync(int roomId);
        Task<IEnumerable<Guest>> GetCurrentGuestsAsync();
        Task<bool> RoomHasGuestsAsync(int roomId);
    }
}
