﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Service.DTOs
{
    public class GuestReadOnlyDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public DateTime DOB { get; set; }
        public string Address { get; set; } = string.Empty;
        public string Nationality { get; set; } = string.Empty;
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public int RoomId { get; set; }
        public string? RoomNumber { get; set; }
        public string? RoomType { get; set; }

        public string FullName => $"{FirstName} {LastName}";
    }

    public class GuestCreateUpdateDto
    {
        [Required(ErrorMessage = "First Name is required.")]
        [StringLength(200, ErrorMessage = "First Name cannot exceed 200 characters.")]
        public string FirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Last Name is required.")]
        [StringLength(400, ErrorMessage = "Last Name cannot exceed 400 characters.")]
        public string LastName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Date of Birth is required.")]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage = "Address is required.")]
        [StringLength(600, ErrorMessage = "Address cannot exceed 600 characters.")]
        public string Address { get; set; } = string.Empty;

        [Required(ErrorMessage = "Nationality is required.")]
        public string Nationality { get; set; } = string.Empty;

        [Required(ErrorMessage = "Check-in Date is required.")]
        public DateTime CheckInDate { get; set; }

        [Required(ErrorMessage = "Check-out Date is required.")]
        public DateTime CheckOutDate { get; set; }

        [Required(ErrorMessage = "Room ID is required.")]
        public int RoomId { get; set; }
    }
}