﻿using AutoMapper;
using Data.Entities;
using Data.Repositories.Interfaces;
using Microsoft.Extensions.Logging; 
using Service.DTOs;
using Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq; 
using System.Threading.Tasks;

namespace Service.Services 
{
    public class RoomService : IRoomService
    {
        private readonly IRoomRepository _roomRepository;     
        private readonly IGuestRepository _guestRepository;   
        private readonly IMapper _mapper;                     
        private readonly ILogger<RoomService> _logger;

        public RoomService(
            IRoomRepository roomRepository,
            IGuestRepository guestRepository,
            IMapper mapper,
            ILogger<RoomService> logger)
        {
            _roomRepository = roomRepository ?? throw new ArgumentNullException(nameof(roomRepository));
            _guestRepository = guestRepository ?? throw new ArgumentNullException(nameof(guestRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<RoomReadOnlyDto?> CreateRoomAsync(RoomCreateUpdateDto roomDto)
        {
            var allRooms = await _roomRepository.GetAllAsync();
            if (allRooms.Any(r => r.Number.Equals(roomDto.Number, StringComparison.OrdinalIgnoreCase)))
            {
                _logger.LogWarning("Attempted to create room with duplicate number: {RoomNumber}", roomDto.Number);
                return null;
            }

            var roomEntity = _mapper.Map<Room>(roomDto);
            await _roomRepository.AddAsync(roomEntity);
            await _roomRepository.SaveChangesAsync();

            _logger.LogInformation("Room created with ID: {RoomId}", roomEntity.Id);
            var createdRoomDto = _mapper.Map<RoomReadOnlyDto>(roomEntity);
            createdRoomDto.GuestCount = 0;
            return createdRoomDto;
        }

        public async Task<bool> DeleteRoomAsync(int id)
        {
            var room = await _roomRepository.GetByIdAsync(id);
            if (room == null)
            {
                _logger.LogWarning("Attempted to delete non-existent room with ID: {RoomId}", id);
                return false;
            }

            if (await _guestRepository.RoomHasGuestsAsync(id))
            {
                _logger.LogWarning("Attempted to delete room ID {RoomId} which has guests.", id);
                return false;
            }

            _roomRepository.Delete(room);
            var result = await _roomRepository.SaveChangesAsync();
            if (result > 0)
            {
                _logger.LogInformation("Room deleted with ID: {RoomId}", id);
                return true;
            }
             _logger.LogWarning("Room with ID: {RoomId} was marked for deletion but not saved.", id);
            return false;
        }

        public async Task<IEnumerable<RoomReadOnlyDto>> GetAllRoomsAsync()
        {
            var rooms = await _roomRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<RoomReadOnlyDto>>(rooms);
        }

        public async Task<RoomReadOnlyDto?> GetRoomByIdAsync(int id)
        {
            var room = await _roomRepository.GetByIdAsync(id);
            if (room == null)
            {
                return null;
            }
            return _mapper.Map<RoomReadOnlyDto>(room);
        }

        public async Task<bool> UpdateRoomAsync(int id, RoomCreateUpdateDto roomDto)
        {
            var existingRoom = await _roomRepository.GetByIdAsync(id);
            if (existingRoom == null)
            {
                _logger.LogWarning("Attempted to update non-existent room with ID: {RoomId}", id);
                return false;
            }

            if (!existingRoom.Number.Equals(roomDto.Number, StringComparison.OrdinalIgnoreCase))
            {
                var allRooms = await _roomRepository.GetAllAsync();
                if (allRooms.Any(r => r.Id != id && r.Number.Equals(roomDto.Number, StringComparison.OrdinalIgnoreCase)))
                {
                    _logger.LogWarning("Attempted to update room ID {RoomId} to a duplicate number: {RoomNumber}", id, roomDto.Number);
                    return false;
                }
            }

            _mapper.Map(roomDto, existingRoom);
            _roomRepository.Update(existingRoom);

            var result = await _roomRepository.SaveChangesAsync();
            if (result > 0)
            {
                _logger.LogInformation("Room updated with ID: {RoomId}", id);
                return true;
            }
            _logger.LogWarning("Room with ID: {RoomId} was marked for update but not saved.", id);
            return false;
        }
    }
}
