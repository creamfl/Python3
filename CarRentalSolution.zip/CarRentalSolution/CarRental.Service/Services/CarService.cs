using AutoMapper;
using CarRental.Data.Entities;
using CarRental.Data.Interfaces;
using CarRental.Service.DTOs;
using CarRental.Service.Interfaces;
using System.Collections.Generic;

namespace CarRental.Service.Services
{
    public class CarService : ICarService
    {
        private readonly ICarRepository _carRepository;
        private readonly IMapper _mapper;

        public CarService(ICarRepository carRepository, IMapper mapper)
        {
            _carRepository = carRepository;
            _mapper = mapper;
        }

        public IEnumerable<CarDTO> GetAllCars()
        {
            var cars = _carRepository.GetAll();
            return _mapper.Map<IEnumerable<CarDTO>>(cars);
        }

        public CarDTO GetCarById(int id)
        {
            var car = _carRepository.GetById(id);
            return _mapper.Map<CarDTO>(car);
        }

        public CarDTO CreateCar(CreateCarDTO carDto)
        {
            var car = _mapper.Map<Car>(carDto);
            var createdCar = _carRepository.Create(car);
            return _mapper.Map<CarDTO>(createdCar);
        }

        public void UpdateCar(int id, UpdateCarDTO carDto)
        {
            var existingCar = _carRepository.GetById(id);
             if (existingCar == null)
            {
                throw new KeyNotFoundException($"Car with ID {id} not found.");
            }
            _mapper.Map(carDto, existingCar);
            _carRepository.Update(existingCar);
        }

        public void DeleteCar(int id)
        {
            var existingCar = _carRepository.GetById(id);
            if (existingCar == null)
            {
                throw new KeyNotFoundException($"Car with ID {id} not found.");
            }
            _carRepository.Delete(id);
        }
    }
}