using Xunit;
using Moq;
using Service.Services;
using Service.Interfaces;
using Data.Repositories.Interfaces;
using Data.Entities;
using Service.DTOs;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Hotel.Tests.Unit.Services
{
    public class RoomServiceTests
    {
        private readonly Mock<IRoomRepository> _mockRoomRepository;
        private readonly Mock<IGuestRepository> _mockGuestRepository; 
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<ILogger<RoomService>> _mockLogger;
        private readonly RoomService _roomService;

        public RoomServiceTests()
        {
            _mockRoomRepository = new Mock<IRoomRepository>();
            _mockGuestRepository = new Mock<IGuestRepository>();
            _mockMapper = new Mock<IMapper>();
            _mockLogger = new Mock<ILogger<RoomService>>();

            _mockMapper.Setup(m => m.Map<RoomReadOnlyDto>(It.IsAny<Room>()))
                       .Returns((Room source) => source == null ? null : new RoomReadOnlyDto { Id = source.Id, Number = source.Number, Type = source.Type, Floor = source.Floor });
            _mockMapper.Setup(m => m.Map<Room>(It.IsAny<RoomCreateUpdateDto>()))
                       .Returns((RoomCreateUpdateDto source) => source == null ? null : new Room { Number = source.Number, Type = source.Type, Floor = source.Floor });


            _roomService = new RoomService(
                _mockRoomRepository.Object,
                _mockGuestRepository.Object,
                _mockMapper.Object,
                _mockLogger.Object
            );
        }

        [Fact]
        public async Task CreateRoomAsync_WithValidData_ShouldReturnCreatedRoomDto()
        {
            // Arrange
            var roomDto = new RoomCreateUpdateDto { Number = "101", Floor = 1, Type = "Single" };
            var roomEntityMappedFromDto = new Room { Number = "101", Floor = 1, Type = "Single" };
            var roomIdAfterSave = 1;


            _mockRoomRepository.Setup(repo => repo.GetAllAsync()).ReturnsAsync(new List<Room>()); 
            _mockRoomRepository.Setup(repo => repo.AddAsync(It.IsAny<Room>()))
                .Callback<Room>(r => r.Id = roomIdAfterSave) // Simulate ID assignment
                .Returns(Task.CompletedTask);
            _mockRoomRepository.Setup(repo => repo.SaveChangesAsync()).ReturnsAsync(1);

            _mockMapper.Setup(m => m.Map<Room>(roomDto)).Returns(roomEntityMappedFromDto);
            // When the service maps the entity (which now has an ID) back to RoomReadOnlyDto
            _mockMapper.Setup(m => m.Map<RoomReadOnlyDto>(It.Is<Room>(r => r.Id == roomIdAfterSave)))
                       .Returns(new RoomReadOnlyDto { Id = roomIdAfterSave, Number = roomDto.Number, Type = roomDto.Type, Floor = roomDto.Floor, GuestCount = 0 });


            // Act
            var result = await _roomService.CreateRoomAsync(roomDto);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(roomDto.Number, result.Number);
            Assert.Equal(roomIdAfterSave, result.Id);
            _mockRoomRepository.Verify(repo => repo.AddAsync(It.Is<Room>(r => r.Number == roomDto.Number)), Times.Once);
            _mockRoomRepository.Verify(repo => repo.SaveChangesAsync(), Times.Once);
        }

        [Fact]
        public async Task CreateRoomAsync_WhenRoomNumberExists_ShouldReturnNull()
        {
            // Arrange
            var roomDto = new RoomCreateUpdateDto { Number = "101", Floor = 1, Type = "Single" };
            var existingRooms = new List<Room> { new Room { Id = 1, Number = "101", Floor = 1, Type = "Single" } };
            _mockRoomRepository.Setup(repo => repo.GetAllAsync()).ReturnsAsync(existingRooms);

            // Act
            var result = await _roomService.CreateRoomAsync(roomDto);

            // Assert
            Assert.Null(result);
            _mockRoomRepository.Verify(repo => repo.AddAsync(It.IsAny<Room>()), Times.Never);
        }

        [Fact]
        public async Task DeleteRoomAsync_WhenRoomExistsAndHasNoGuests_ShouldReturnTrue()
        {
            // Arrange
            var roomId = 1;
            var roomEntity = new Room { Id = roomId, Number = "101" };
            _mockRoomRepository.Setup(repo => repo.GetByIdAsync(roomId)).ReturnsAsync(roomEntity);
            _mockGuestRepository.Setup(repo => repo.RoomHasGuestsAsync(roomId)).ReturnsAsync(false); 
            _mockRoomRepository.Setup(repo => repo.Delete(roomEntity));
            _mockRoomRepository.Setup(repo => repo.SaveChangesAsync()).ReturnsAsync(1);

            // Act
            var result = await _roomService.DeleteRoomAsync(roomId);

            // Assert
            Assert.True(result);
            _mockRoomRepository.Verify(repo => repo.Delete(roomEntity), Times.Once);
            _mockRoomRepository.Verify(repo => repo.SaveChangesAsync(), Times.Once);
        }

        [Fact]
        public async Task DeleteRoomAsync_WhenRoomHasGuests_ShouldReturnFalse()
        {
            // Arrange
            var roomId = 1;
            var roomEntity = new Room { Id = roomId, Number = "101" };
            _mockRoomRepository.Setup(repo => repo.GetByIdAsync(roomId)).ReturnsAsync(roomEntity);
            _mockGuestRepository.Setup(repo => repo.RoomHasGuestsAsync(roomId)).ReturnsAsync(true); 

            // Act
            var result = await _roomService.DeleteRoomAsync(roomId);

            // Assert
            Assert.False(result); 
            _mockRoomRepository.Verify(repo => repo.Delete(It.IsAny<Room>()), Times.Never);
        }
         [Fact]
        public async Task GetRoomByIdAsync_WhenRoomExists_ShouldReturnRoomDto()
        {
            // Arrange
            var roomId = 1;
            var roomEntity = new Room { Id = roomId, Number = "101", Type = "Single", Floor = 1 };
            _mockRoomRepository.Setup(repo => repo.GetByIdAsync(roomId)).ReturnsAsync(roomEntity);
            _mockMapper.Setup(m => m.Map<RoomReadOnlyDto>(roomEntity))
                       .Returns(new RoomReadOnlyDto { Id = roomEntity.Id, Number = roomEntity.Number, Type = roomEntity.Type, Floor = roomEntity.Floor });


            // Act
            var result = await _roomService.GetRoomByIdAsync(roomId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(roomId, result.Id);
            Assert.Equal("101", result.Number);
        }
    }
}
