﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Service.DTOs
{
    public class RoomReadOnlyDto
    {
        public int Id { get; set; }
        public string Number { get; set; } = string.Empty;
        public int Floor { get; set; }
        public string Type { get; set; } = string.Empty;
        public int GuestCount { get; set; } 
    }


    public class RoomCreateUpdateDto
    {
        [Required(ErrorMessage = "Room Number is required.")]
        public string Number { get; set; } = string.Empty;

        [Required(ErrorMessage = "Floor is required.")]
        public int Floor { get; set; }

        [Required(ErrorMessage = "Room Type is required.")]
        public string Type { get; set; } = string.Empty;
    }
}
