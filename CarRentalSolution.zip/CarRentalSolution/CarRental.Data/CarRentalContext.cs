using CarRental.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace CarRental.Data
{
    public class CarRentalContext : DbContext
    {
        public CarRentalContext(DbContextOptions<CarRentalContext> options) : base(options)
        {
        }

        public DbSet<Client> Clients { get; set; }
        public DbSet<Car> Cars { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Client>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
                entity.Property(e => e.FirstName).IsRequired().HasMaxLength(200);
                entity.Property(e => e.LastName).IsRequired().HasMaxLength(400);
                entity.Property(e => e.DOB).IsRequired();
                entity.Property(e => e.Address).IsRequired().HasMaxLength(500);
                entity.Property(e => e.Nationality).IsRequired();
                entity.Property(e => e.RentalStartDate).IsRequired();
                entity.Property(e => e.RentalEndDate).IsRequired();

                entity.HasOne(c => c.Car)
                      .WithMany(r => r.Clients)
                      .HasForeignKey(c => c.CarId);
            });

            modelBuilder.Entity<Car>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
                entity.Property(e => e.LicensePlate).IsRequired();
                entity.Property(e => e.Model).IsRequired();
                entity.Property(e => e.Manufacturer).IsRequired();
                entity.Property(e => e.Year).IsRequired();
            });
        }
    }
}