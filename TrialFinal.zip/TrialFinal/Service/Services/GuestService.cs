﻿using AutoMapper;
using Data.Entities;
using Data.Repositories.Interfaces;
using Microsoft.Extensions.Logging;
using Service.DTOs;
using Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Service.Services
{
    public class GuestService : IGuestService
    {
        private readonly IGuestRepository _guestRepository;
        private readonly IRoomRepository _roomRepository;   
        private readonly IMapper _mapper;                   
        private readonly ILogger<GuestService> _logger;     

        public GuestService(
            IGuestRepository guestRepository,
            IRoomRepository roomRepository,
            IMapper mapper,
            ILogger<GuestService> logger)
        {
            _guestRepository = guestRepository ?? throw new ArgumentNullException(nameof(guestRepository));
            _roomRepository = roomRepository ?? throw new ArgumentNullException(nameof(roomRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<GuestReadOnlyDto?> CreateGuestAsync(GuestCreateUpdateDto guestDto)
        {
            // Business Rule: Check if the room exists before assigning a guest to it
            var roomExists = await _roomRepository.GetByIdAsync(guestDto.RoomId);
            if (roomExists == null)
            {
                _logger.LogWarning("Attempted to create guest for non-existent room ID: {RoomId}", guestDto.RoomId);

                return null;
            }

            if (guestDto.CheckOutDate <= guestDto.CheckInDate)
            {
                _logger.LogWarning("Attempted to create guest with invalid check-out date (must be after check-in date). CheckIn: {CheckIn}, CheckOut: {CheckOut}", guestDto.CheckInDate, guestDto.CheckOutDate);

                return null;
            }

            var guestEntity = _mapper.Map<Guest>(guestDto);
            await _guestRepository.AddAsync(guestEntity);
            await _guestRepository.SaveChangesAsync(); 

            _logger.LogInformation("Guest created with ID: {GuestId}", guestEntity.Id);
            var createdGuestWithDetails = await _guestRepository.GetByIdAsync(guestEntity.Id);
            return _mapper.Map<GuestReadOnlyDto>(createdGuestWithDetails);
        }

        public async Task<bool> DeleteGuestAsync(int id)
        {
            var guest = await _guestRepository.GetByIdAsync(id);
            if (guest == null)
            {
                _logger.LogWarning("Attempted to delete non-existent guest with ID: {GuestId}", id);
                return false;
            }

            _guestRepository.Delete(guest);
            var result = await _guestRepository.SaveChangesAsync();
            if (result > 0)
            {
                _logger.LogInformation("Guest deleted with ID: {GuestId}", id);
                return true;
            }
            _logger.LogWarning("Guest with ID: {GuestId} was marked for deletion but not saved.", id);
            return false;
        }

        public async Task<IEnumerable<GuestReadOnlyDto>> GetAllGuestsAsync()
        {
            var guests = await _guestRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<GuestReadOnlyDto>>(guests);
        }

        public async Task<GuestReadOnlyDto?> GetGuestByIdAsync(int id)
        {
            var guest = await _guestRepository.GetByIdAsync(id);
            if (guest == null)
            {
                return null;
            }
            return _mapper.Map<GuestReadOnlyDto>(guest);
        }

        public async Task<bool> UpdateGuestAsync(int id, GuestCreateUpdateDto guestDto)
        {
            var existingGuest = await _guestRepository.GetByIdAsync(id);
            if (existingGuest == null)
            {
                _logger.LogWarning("Attempted to update non-existent guest with ID: {GuestId}", id);
                return false;
            }

            var roomExists = await _roomRepository.GetByIdAsync(guestDto.RoomId);
            if (roomExists == null)
            {
                _logger.LogWarning("Attempted to update guest to non-existent room ID: {RoomId}", guestDto.RoomId);
                return false;
            }

            if (guestDto.CheckOutDate <= guestDto.CheckInDate)
            {
                _logger.LogWarning("Attempted to update guest with invalid check-out date. GuestID: {GuestId}", id);
                return false;
            }

            _mapper.Map(guestDto, existingGuest);
            _guestRepository.Update(existingGuest);

            var result = await _guestRepository.SaveChangesAsync();
            if (result > 0)
            {
                _logger.LogInformation("Guest updated with ID: {GuestId}", id);
                return true;
            }
            _logger.LogWarning("Guest with ID: {GuestId} was marked for update but not saved.", id);
            return false;
        }
    }
}
