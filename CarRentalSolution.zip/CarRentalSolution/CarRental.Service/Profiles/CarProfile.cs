using AutoMapper;
using CarRental.Data.Entities;
using CarRental.Service.DTOs;

namespace CarRental.Service.Profiles
{
    public class CarProfile : Profile
    {
        public CarProfile()
        {
            CreateMap<Car, CarDTO>().ReverseMap();
            CreateMap<Car, CreateCarDTO>().ReverseMap();
            CreateMap<Car, UpdateCarDTO>().ReverseMap();
        }
    }
}