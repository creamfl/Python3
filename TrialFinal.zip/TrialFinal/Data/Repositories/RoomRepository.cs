﻿using Data.Entities;
using Data.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Data.Repositories
{
    public class RoomRepository : IRoomRepository
    {
        private readonly AppDbContext _context;

        public RoomRepository(AppDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<IEnumerable<Room>> GetAllAsync()
        {
            return await _context.Rooms
                .Include(r => r.Guests)
                .ToListAsync();
        }

        public async Task<Room?> GetByIdAsync(int id)
        {
            return await _context.Rooms
                .Include(r => r.Guests)
                .FirstOrDefaultAsync(r => r.Id == id);
        }

        public async Task AddAsync(Room entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            await _context.Rooms.AddAsync(entity);
        }

        public void Update(Room entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            _context.Rooms.Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;
        }

        public void Delete(Room entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
            if (_context.Entry(entity).State == EntityState.Detached)
            {
                _context.Rooms.Attach(entity);
            }
            _context.Rooms.Remove(entity);
        }

        public async Task DeleteAsync(int id)
        {
            var room = await GetByIdAsync(id);
            if (room != null)
            {
                Delete(room);
            }
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }


        public async Task<IEnumerable<Room>> GetRoomsByFloorAsync(int floor)
        {
            return await _context.Rooms
                .Where(r => r.Floor == floor)
                .Include(r => r.Guests)
                .ToListAsync();
        }

        public async Task<IEnumerable<Room>> GetAvailableRoomsAsync(DateTime startDate, DateTime endDate)
        {
            var occupiedRoomIds = await _context.Guests
                .Where(g => g.CheckInDate < endDate && g.CheckOutDate > startDate)
                .Select(g => g.RoomId)
                .Distinct()
                .ToListAsync();

            return await _context.Rooms
                .Where(r => !occupiedRoomIds.Contains(r.Id))
                .Include(r => r.Guests)
                .ToListAsync();
        }

        public async Task<bool> IsRoomAvailableAsync(int roomId, DateTime startDate, DateTime endDate)
        {
            return !await _context.Guests
                .AnyAsync(g => g.RoomId == roomId &&
                               g.CheckInDate < endDate &&
                               g.CheckOutDate > startDate);
        }
    }
}
