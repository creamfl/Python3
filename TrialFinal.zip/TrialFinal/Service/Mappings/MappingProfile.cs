using AutoMapper;
using Data.Entities;
using Service.DTOs;
using System.Linq;

namespace Service.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Guest, GuestReadOnlyDto>()
                .ForMember(dest => dest.RoomNumber, opt => opt.MapFrom(src => src.Room != null ? src.Room.Number : null))
                .ForMember(dest => dest.RoomType, opt => opt.MapFrom(src => src.Room != null ? src.Room.Type : null));


            CreateMap<GuestCreateUpdateDto, Guest>();

            CreateMap<Room, RoomReadOnlyDto>()
                .ForMember(dest => dest.GuestCount, opt => opt.MapFrom(src => src.Guests != null ? src.Guests.Count : 0));

            CreateMap<RoomCreateUpdateDto, Room>();
        }
    }
}
