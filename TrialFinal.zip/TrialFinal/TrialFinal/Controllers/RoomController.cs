﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service.DTOs;
using Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TrialFinal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomsController : ControllerBase
    {
        private readonly IRoomService _roomService;
        private readonly ILogger<RoomsController> _logger;

        public RoomsController(IRoomService roomService, ILogger<RoomsController> logger)
        {
            _roomService = roomService ?? throw new ArgumentNullException(nameof(roomService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<RoomReadOnlyDto>), StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<RoomReadOnlyDto>>> GetAllRooms()
        {
            _logger.LogInformation("Attempting to get all rooms.");
            var rooms = await _roomService.GetAllRoomsAsync();
            return Ok(rooms);
        }

        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(RoomReadOnlyDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<RoomReadOnlyDto>> GetRoomById(int id)
        {
            _logger.LogInformation("Attempting to get room with ID: {RoomId}", id);
            var room = await _roomService.GetRoomByIdAsync(id);
            if (room == null)
            {
                _logger.LogWarning("Room with ID: {RoomId} not found.", id);
                return NotFound($"Room with ID {id} not found.");
            }
            return Ok(room);
        }

        [HttpPost]
        [ProducesResponseType(typeof(RoomReadOnlyDto), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<RoomReadOnlyDto>> CreateRoom([FromBody] RoomCreateUpdateDto roomDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                _logger.LogInformation("Attempting to create a new room: Number {RoomNumber}, Type {RoomType}", roomDto.Number, roomDto.Type);
                var createdRoom = await _roomService.CreateRoomAsync(roomDto);
                if (createdRoom == null)
                {
                     _logger.LogWarning("Room creation failed due to service-level validation for room: {RoomNumber}", roomDto.Number);
                    return BadRequest("Room creation failed. Please check input data (e.g., duplicate room number).");
                }
                return CreatedAtAction(nameof(GetRoomById), new { id = createdRoom.Id }, createdRoom);
            }
            catch (ArgumentException ex)
            {
                _logger.LogWarning(ex, "Argument error while creating room: {RoomNumber}", roomDto.Number);
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error while creating room: {RoomNumber}", roomDto.Number);
                return StatusCode(StatusCodes.Status500InternalServerError, "An unexpected error occurred while creating the room.");
            }
        }

        [HttpPut("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateRoom(int id, [FromBody] RoomCreateUpdateDto roomDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("Attempting to update room with ID: {RoomId}", id);
            var success = await _roomService.UpdateRoomAsync(id, roomDto);

            if (!success)
            {
                var roomExists = await _roomService.GetRoomByIdAsync(id);
                if (roomExists == null)
                {
                    _logger.LogWarning("Attempted to update non-existent room with ID: {RoomId}", id);
                    return NotFound($"Room with ID {id} not found.");
                }
                _logger.LogWarning("Update failed for room ID: {RoomId}. Possible duplicate number or other validation.", id);
                return BadRequest("Room update failed. Please check input data.");
            }
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteRoom(int id)
        {
            _logger.LogInformation("Attempting to delete room with ID: {RoomId}", id);
            var success = await _roomService.DeleteRoomAsync(id);
            if (!success)
            {
                var roomExists = await _roomService.GetRoomByIdAsync(id);
                if (roomExists == null)
                {
                     _logger.LogWarning("Attempted to delete non-existent room with ID: {RoomId}", id);
                    return NotFound($"Room with ID {id} not found.");
                }
                _logger.LogWarning("Failed to delete room ID {RoomId}, likely because it has guests or another rule violation.", id);
                return BadRequest($"Cannot delete room with ID {id}. It might have associated guests or other dependencies.");
            }
            return NoContent();
        }
    }
}
