﻿namespace ISExam.Api.Infrastructure
{
    public class ConnectionStrings
    {
        public string DefaultConnection { get; set; }
    }
}
