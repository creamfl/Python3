using CarRental.Data.Entities;
using System.Collections.Generic;

namespace CarRental.Data.Interfaces
{
    public interface IClientRepository
    {
        IEnumerable<Client> GetAll();
        Client GetById(int id);
        Client Create(Client client);
        void Update(Client client);
        void Delete(int id);
    }
}