using CarRental.Service.DTOs;
using System.Collections.Generic;

namespace CarRental.Service.Interfaces
{
    public interface IClientService
    {
        IEnumerable<ClientDTO> GetAllClients();
        ClientDTO GetClientById(int id);
        ClientDTO CreateClient(CreateClientDTO clientDto);
        void UpdateClient(int id, UpdateClientDTO clientDto);
        void DeleteClient(int id);
    }
}