using AutoMapper;
using CarRental.Data.Entities;
using CarRental.Service.DTOs;

namespace CarRental.Service.Profiles
{
    public class ClientProfile : Profile
    {
        public ClientProfile()
        {
            CreateMap<Client, ClientDTO>().ReverseMap();
            CreateMap<Client, CreateClientDTO>().ReverseMap();
            CreateMap<Client, UpdateClientDTO>().ReverseMap();
        }
    }
}